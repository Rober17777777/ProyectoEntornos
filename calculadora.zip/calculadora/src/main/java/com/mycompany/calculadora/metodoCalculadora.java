/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.calculadora;

/**
 *
 * @author rober
 */
public class metodoCalculadora {
    
        public static double dividir(double numero1, double numero2) {
        if (numero2 == 0) {
            throw new ArithmeticException("No se puede dividir entre cero");
        }
        return numero1 / numero2;
    }

    public static void main(String[] args) {
        double resultado = dividir(20, 2);
        System.out.println("El resultado de la división es: " + resultado);
    }
}


