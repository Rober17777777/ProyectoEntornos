/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/UnitTests/JUnit5TestClass.java to edit this template
 */

import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.AfterAll;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;
import com.mycompany.calculadora.Calculadora;
/**
 *
 * @author rober
 */
public class testCalculadora {
    
   

    
    @Test
    public void testDividir() {
        // Arrange
        int dividendo = 20;
        int divisor = 2;
        int resultadoEsperado = 10;
        
        // Act
        int resultado = Calculadora.dividir(dividendo, divisor);
        
        // Assert
        assertEquals(resultadoEsperado, resultado);
    }
}


